#!/bin/bash
ansible-playbook -i ./hosts $1