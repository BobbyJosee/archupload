# django_ansible
Example repository for a tutorial on how to deploy Django with Ansible

See the blog post here for a full explaination of the content of this repository:

https://baxeico.wordpress.com/2017/05/02/how-to-deploy-a-django-project-in-15-minutes-with-ansible/
